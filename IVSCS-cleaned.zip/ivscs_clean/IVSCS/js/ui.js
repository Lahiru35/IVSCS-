/* ================================================================
   JS SECTION 4 — UI UPDATE FUNCTIONS
   Read from state object and update the HTML elements.
   Called every ~4 frames (~15 fps) from the main loop.
================================================================ */

// Master update — calls all sub-updates in order
function updateUI() {
  updateSensors();
  updateRisk();
  updateActions();
  updateWorkflow();
  updateBottomBar();
  updateStatusBadge();
}

// Update all 5 sensor cards
function updateSensors() {
  // Grip: lower % = worse (danger < 30%, warning < 60%)
  const gPct = Math.round(state.grip * 100);
  document.getElementById('v-grip').innerHTML = state.grip.toFixed(2) + ' <span>&#956;</span>';
  setBar('b-grip', gPct, gPct < 30, gPct < 60);
  document.getElementById('s-grip').className = 'sensor-item' + (gPct < 30 ? ' danger' : gPct < 60 ? ' warning' : '');

  // Vibration: higher % = worse (danger > 60%, warning > 30%)
  const vPct = Math.min(100, Math.round(state.vib * 2));
  document.getElementById('v-vib').innerHTML = Math.round(state.vib) + ' <span>Hz</span>';
  setBar('b-vib', vPct, vPct > 60, vPct > 30);
  document.getElementById('s-vib').className = 'sensor-item' + (vPct > 60 ? ' danger' : vPct > 30 ? ' warning' : '');

  // Front distance: lower % = worse (danger < 20%, warning < 40%)
  const fPct = Math.min(100, Math.round((state.frontDist / 60) * 100));
  document.getElementById('v-front').innerHTML = Math.round(state.frontDist) + ' <span>m</span>';
  setBar('b-front', fPct, fPct < 20, fPct < 40);
  document.getElementById('s-front').className = 'sensor-item' + (fPct < 20 ? ' danger' : fPct < 40 ? ' warning' : '');

  // Rear speed: higher % = worse (danger > 60%, warning > 30%)
  const rPct = Math.min(100, Math.round((state.rearSpeed / 150) * 100));
  document.getElementById('v-rear').innerHTML = Math.round(state.rearSpeed) + ' <span>km/h</span>';
  setBar('b-rear', rPct, rPct > 60, rPct > 30);
  document.getElementById('s-rear').className = 'sensor-item' + (rPct > 60 ? ' danger' : rPct > 30 ? ' warning' : '');

  // Object detection: simple text + colour change
  const o = document.getElementById('v-obj');
  o.textContent = state.objDetected ? '! DETECTED' : 'CLEAR';
  o.style.color = state.objDetected ? '#ffd600' : '#39ff14';
  document.getElementById('s-obj').className = 'sensor-item' + (state.objDetected ? ' warning' : '');
}

// Helper: set a sensor bar's width and colour (green / yellow / red)
function setBar(id, pct, isDanger, isWarn) {
  const el = document.getElementById(id);
  el.style.width      = pct + '%';
  el.style.background = isDanger ? '#ff1744' : isWarn ? '#ffd600' : '#39ff14';
}

// Update the SVG risk ring (stroke-dashoffset fills the circle arc)
function updateRisk() {
  const arc = document.getElementById('risk-arc');
  const val = document.getElementById('risk-val');
  const col = state.risk > 70 ? '#ff1744' : state.risk > 40 ? '#ffd600' : '#39ff14';
  arc.setAttribute('stroke-dashoffset', 264 - (state.risk / 100) * 264);
  arc.setAttribute('stroke', col);
  val.textContent = Math.round(state.risk) + '%';
  val.style.color = col;
  document.getElementById('speed-val').textContent = Math.round(state.speed);
}

// Update the top status badge
function updateStatusBadge() {
  const b = document.getElementById('status-badge');
  const t = document.getElementById('status-text');
  if      (state.risk > 70) { b.className = 'status-badge danger';  t.textContent = 'CRITICAL — INTERVENTION ACTIVE'; }
  else if (state.risk > 40) { b.className = 'status-badge warning'; t.textContent = 'WARNING — MONITORING ELEVATED'; }
  else                      { b.className = 'status-badge active';  t.textContent = 'ALL SYSTEMS NOMINAL'; }
}

// Update action buttons (.active when system is running)
function updateActions() {
  setBtn('act-ecu',      state.ecuActive,      'REDUCING',  'NOMINAL',  '#ff6b35');
  setBtn('act-brake',    state.brakeActive,     'ENGAGED',   'STANDBY',  '#ff6b35');
  setBtn('act-antiskid', state.antiskidActive,  'ACTIVE',    'IDLE',     '#ffd600');
  document.getElementById('act-balloon').className     = 'action-btn' + (state.balloonDeployed ? ' fired' : '');
  document.getElementById('act-balloon-s').textContent = state.balloonDeployed ? 'DEPLOYED!' : 'ARMED';
  document.getElementById('act-balloon-s').style.color = state.balloonDeployed ? '#ff1744' : '#6a8faf';
  document.getElementById('balloon').classList.toggle('show', state.balloonDeployed);
}

// Helper: update one action button
function setBtn(id, active, onLabel, offLabel, onColour) {
  document.getElementById(id).className          = 'action-btn' + (active ? ' active' : '');
  document.getElementById(id+'-s').textContent   = active ? onLabel : offLabel;
  document.getElementById(id+'-s').style.color   = active ? onColour : '#6a8faf';
}

// Highlight workflow steps based on risk level
function updateWorkflow() {
  ['wf1','wf2','wf3','wf4','wf5'].forEach((id, i) => {
    const el = document.getElementById(id);
    if      (state.risk > 70 && i >= 2) { el.style.cssText = 'border-color:#ff1744;background:rgba(255,23,68,0.12);color:#ff6b6b'; }
    else if (state.risk > 40 && i >= 1) { el.style.cssText = 'border-color:#ffd600;background:rgba(255,214,0,0.08);color:#ffd600'; }
    else                                { el.style.cssText = 'border-color:rgba(0,229,255,0.15);background:#0a1f3d;color:#c8e6f7'; }
  });
}

// Update the 5 bottom stat cards
function updateBottomBar() {
  document.getElementById('s-react').textContent  = state.brakeActive ? '8' : '18';
  document.getElementById('s-torque').textContent = Math.round(state.torque);
  document.getElementById('s-bpress').textContent = state.brakePressure.toFixed(1);
  document.getElementById('s-events').textContent = events;
  const r = document.getElementById('s-road');
  r.textContent = state.roadState;
  r.style.color = state.roadState === 'ICY' ? '#00e5ff' : state.roadState === 'WET' ? '#64b5f6' : '#39ff14';
}


/* ================================================================
   JS SECTION 5 — AI LOG
   Adds a timestamped message to the scrolling log.
   type = 'safe' | 'warn' | 'err' | 'cmd' | '' (plain white)
================================================================ */
function log(msg, type = '') {
  const el      = document.getElementById('ai-log');
  const elapsed = String(Math.floor((Date.now() - startTime) / 1000)).padStart(5, '0');
  const div     = document.createElement('div');
  div.innerHTML = `<span class="ts">[${elapsed}s]</span><span class="${type}">${msg}</span>`;
  div.style.animation = 'slide-in 0.3s ease';
  el.appendChild(div);
  el.scrollTop = el.scrollHeight;
  while (el.children.length > 20) el.removeChild(el.firstChild); // keep max 20 entries
}
