/* ================================================================
   JS SECTION 3 — RADAR CANVAS
   Draws grid rings, sweep fan, vehicle marker, and threat blips.
   Called every animation frame for smooth rotation.
================================================================ */
const canvas = document.getElementById('radar-canvas');
const ctx    = canvas.getContext('2d');
const CX = 130, CY = 130;  // canvas centre coordinates
let radarAngle = 0;         // current sweep angle (radians)

function drawRadar() {
  ctx.clearRect(0, 0, 260, 260);
  ctx.fillStyle = '#040d1a';
  ctx.fillRect(0, 0, 260, 260);

  // Concentric range rings (every 30px)
  for (let r = 30; r <= 120; r += 30) {
    ctx.beginPath();
    ctx.arc(CX, CY, r, 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(0,229,255,0.08)';
    ctx.lineWidth = 0.5;
    ctx.stroke();
  }

  // Cross-hair lines through centre
  ctx.strokeStyle = 'rgba(0,229,255,0.08)'; ctx.lineWidth = 0.5;
  ctx.beginPath(); ctx.moveTo(CX-120, CY); ctx.lineTo(CX+120, CY); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(CX, CY-120); ctx.lineTo(CX, CY+120); ctx.stroke();

  // Rotating sweep fan (gradient from cyan to transparent)
  ctx.save();
  ctx.translate(CX, CY);
  ctx.rotate(radarAngle);
  const g = ctx.createLinearGradient(0, 0, 120, 0);
  g.addColorStop(0, 'rgba(0,229,255,0.35)');
  g.addColorStop(1, 'rgba(0,229,255,0)');
  ctx.beginPath(); ctx.moveTo(0,0); ctx.arc(0, 0, 120, -0.3, 0); ctx.closePath();
  ctx.fillStyle = g; ctx.fill();
  ctx.restore();

  // Ego vehicle marker (small rounded rectangle at centre)
  ctx.save();
  ctx.translate(CX, CY);
  ctx.fillStyle = 'rgba(0,229,255,0.9)';
  ctx.beginPath(); ctx.roundRect(-8, -14, 16, 28, 3); ctx.fill();
  ctx.restore();

  // Scenario overlays: show threat blips when active
  if (scenario === 'object') {
    // Yellow blip ahead = pedestrian detected by camera
    ctx.beginPath(); ctx.arc(CX, CY-65, 8, 0, Math.PI*2); ctx.fillStyle = 'rgba(255,214,0,0.9)'; ctx.fill();
    ctx.beginPath(); ctx.arc(CX, CY-65, 14, 0, Math.PI*2); ctx.fillStyle = 'rgba(255,214,0,0.2)'; ctx.fill();
    ctx.fillStyle = 'rgba(0,229,255,0.7)'; ctx.font = '9px Share Tech Mono'; ctx.textAlign = 'center';
    ctx.fillText('PEDESTRIAN', CX, CY-80);
  }
  if (scenario === 'rear') {
    // Red blip behind = fast-approaching vehicle
    ctx.beginPath(); ctx.arc(CX, CY+80, 10, 0, Math.PI*2); ctx.fillStyle = 'rgba(255,23,68,0.9)'; ctx.fill();
    ctx.beginPath(); ctx.arc(CX, CY+80, 18, 0, Math.PI*2); ctx.fillStyle = 'rgba(255,23,68,0.2)'; ctx.fill();
    ctx.fillStyle = 'rgba(255,23,68,0.7)'; ctx.font = '9px Share Tech Mono'; ctx.textAlign = 'center';
    ctx.fillText('INCOMING', CX, CY+100);
  }

  radarAngle += 0.04; // advance sweep angle each frame
}
