/* ================================================================
   JS SECTION 6 — SCENARIO CONTROLLER
   4 scenarios demonstrate different danger situations.
   Each sets state values and logs messages to the AI log.
================================================================ */
let scenario      = 'normal';
let scenarioTimer = null;

function setScenario(s) {
  document.querySelectorAll('.scen-btn').forEach(b => b.classList.remove('active'));
  document.getElementById('scen-' + s).classList.add('active');
  if (scenarioTimer) { clearTimeout(scenarioTimer); scenarioTimer = null; }
  scenario = s;

  if (s === 'normal') {
    // Reset everything to safe baseline values
    Object.assign(state, {
      grip:0.87, vib:12, frontDist:48, rearSpeed:0, objDetected:false,
      risk:2, speed:72, torque:100, brakePressure:0,
      brakeActive:false, antiskidActive:false, ecuActive:false,
      balloonDeployed:false, roadState:'DRY'
    });
    log('Scenario NORMAL — all clear', 'safe');
  }

  else if (s === 'slip') {
    // Icy road: low grip triggers anti-skid and torque reduction
    Object.assign(state, { grip:0.18, vib:38, roadState:'ICY', risk:55, antiskidActive:true, ecuActive:true, torque:55, brakePressure:2.4 });
    log('WARNING: Slippery road — grip 0.18μ', 'warn');
    log('AI: Anti-skid control activated', 'cmd');
    log('AI: Engine torque reduced to 55%', 'cmd');
    events++;
    // After 3s: grip stabilises, risk reduces
    scenarioTimer = setTimeout(() => { log('Grip stabilizing — recovery in progress', 'safe'); state.risk = 35; }, 3000);
  }

  else if (s === 'object') {
    // Pedestrian detected: emergency braking sequence in 3 phases
    Object.assign(state, { frontDist:12, objDetected:true, risk:75, speed:42, brakeActive:true, ecuActive:true, torque:30, brakePressure:7.8 });
    log('CRITICAL: Object detected — 12m ahead', 'err');
    log('AI: Emergency brake pre-charge initiated', 'cmd');
    log('AI: Smart braking ENGAGED', 'cmd');
    events++;
    // Phase 2 (2s later): vehicle decelerating
    scenarioTimer = setTimeout(() => {
      state.frontDist = 28; state.speed = 18;
      log('Vehicle decelerating — 18 km/h', 'warn');
      // Phase 3 (3s later): safe stop achieved
      scenarioTimer = setTimeout(() => {
        Object.assign(state, { speed:0, frontDist:3.5, risk:8, brakeActive:false, objDetected:false });
        log('SAFE STOP achieved — 3.5m clearance', 'safe');
        events++;
      }, 3000);
    }, 2000);
  }

  else if (s === 'rear') {
    // Vehicle approaching fast from behind: deploy safety balloon
    Object.assign(state, { rearSpeed:118, risk:95, balloonDeployed:true });
    log('CRITICAL: Rear collision imminent!', 'err');
    log('AI: Rear approach speed 118 km/h', 'err');
    log('AI: DEPLOYING exterior safety balloon', 'cmd');
    events++;
    // Phase 2 (1.5s later): balloon deployed
    scenarioTimer = setTimeout(() => {
      log('Balloon DEPLOYED — impact cushioned', 'warn');
      // Phase 3 (2.5s later): threat neutralised
      scenarioTimer = setTimeout(() => {
        state.rearSpeed = 0; state.risk = 30;
        log('Rear threat neutralized — monitoring', 'safe');
      }, 2500);
    }, 1500);
  }
}
