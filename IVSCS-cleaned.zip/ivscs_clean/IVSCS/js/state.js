/* ================================================================
   JS SECTION 1 — STATE OBJECT
   Single source of truth. Every sensor value lives here.
   JS writes to this object. updateUI() reads it to update the HTML.
================================================================ */
const state = {
  grip:            0.87,   // wheel friction (0 = no grip, 1 = full grip)
  vib:             12,     // road vibration in Hz
  frontDist:       48,     // metres to front obstacle
  rearSpeed:       0,      // approach speed of vehicle behind (km/h)
  objDetected:     false,  // camera has detected a pedestrian/vehicle
  risk:            2,      // collision risk score 0–100
  speed:           72,     // vehicle speed (km/h)
  torque:          100,    // engine torque as percentage
  brakePressure:   0,      // hydraulic brake pressure (bar)
  brakeActive:     false,  // smart braking is engaged
  antiskidActive:  false,  // anti-skid is running
  ecuActive:       false,  // ECU is reducing torque
  balloonArmed:    true,   // safety balloon is armed and ready
  balloonDeployed: false,  // safety balloon has been deployed
  roadState:       'DRY',  // 'DRY' | 'WET' | 'ICY'
};


/* ================================================================
   JS SECTION 2 — GLOBAL COUNTERS
================================================================ */
let events     = 0;          // number of safety interventions logged
let startTime  = Date.now(); // boot time (used for log timestamps)
let frameCount = 0;          // counts animation frames
