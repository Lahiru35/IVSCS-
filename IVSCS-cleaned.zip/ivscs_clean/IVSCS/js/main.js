/* ================================================================
   JS SECTION 7 — SENSOR NOISE
   Adds tiny random variations during normal mode so the dashboard
   looks like a live system (not frozen).
================================================================ */
function addNoise() {
  if (scenario !== 'normal') return;
  state.grip      = Math.min(0.99, Math.max(0.75, state.grip      + (Math.random()-0.5)*0.03));
  state.vib       = Math.max(8,    Math.min(20,   state.vib       + (Math.random()-0.5)*4));
  state.frontDist = Math.max(30,   Math.min(60,   state.frontDist + (Math.random()-0.5)*3));
  state.risk      = Math.max(1,    Math.min(8,    state.risk      + (Math.random()-0.5)*2));
  state.speed     = Math.max(68,   Math.min(76,   state.speed     + (Math.random()-0.5)*1));
}


/* ================================================================
   JS SECTION 8 — CLOCK
================================================================ */
function updateClock() {
  const n = new Date();
  document.getElementById('clock').textContent =
    String(n.getHours()).padStart(2,'0') + ':' +
    String(n.getMinutes()).padStart(2,'0') + ':' +
    String(n.getSeconds()).padStart(2,'0');
}


/* ================================================================
   JS SECTION 9 — MAIN ANIMATION LOOP
   requestAnimationFrame fires at ~60fps.
   Radar drawn every frame (smooth).
   Everything else updated every 4 frames (~15fps).
================================================================ */
function loop() {
  drawRadar();
  frameCount++;
  if (frameCount % 4 === 0) {
    addNoise();
    updateUI();
    updateClock();
  }
  requestAnimationFrame(loop);
}


/* ================================================================
   JS SECTION 10 — BOOT
   Called once when the page loads.
================================================================ */
setScenario('normal'); // set initial state + write boot messages to log
loop();                // start the animation loop
